import time
from subprocess import call

while True:
	call(['aws','s3','sync','.','s3://smartdashboard.site/data'])
	time.sleep(10)